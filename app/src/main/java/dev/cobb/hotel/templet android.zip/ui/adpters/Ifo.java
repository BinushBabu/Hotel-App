package dev.cobb.hotel.ui.adpters;

/**
 * @author dev.cobb
 * @version 1.0
 * @since 22 may 2017
 */
public class Ifo {
}
